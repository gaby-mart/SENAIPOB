preco = 50
desconto = 10

print(f'O valor do produto com desconto é: {preco - desconto}')