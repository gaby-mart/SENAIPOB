nome = "João" # Exercício 1

print(f'{nome}')