import math

raio = float(input("Digite o raio: "))
raio = math.pow(raio, 2)

area = math.pi * raio

print(f'A área do circulo é {area: .2f}')