peco = int(input("Digite o valor do produto:"))

preco = str(peco)

print(f'O preço do produto é ' + preco)
