import math

x1 = int(input('Digite a cordenada x1: '))
x2 = int(input('Digite a cordenada x2: '))

y1 = int(input('Digite a cordenada y1: '))
y2 = int(input('Digite a cordenada y2: '))

d = math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

print(f'A distância entre os ponto é: {d:.2f}')