x= int(input("Digite o primeiro numero: "))
y = int(input("Digite o segundo numero: "))

multiplicacao = x * y
print(f'{multiplicacao}')