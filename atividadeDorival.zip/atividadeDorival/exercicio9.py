num1 = int(input("Digite o primeiro numero: "))
num2 = int(input("Digite o segundo numero: "))

print(f'O {num1} é maior que o {num2} {num1>num2}.')