idade = int(input("Digite sua idade: "))

diasVida= idade * 365

print(diasVida)