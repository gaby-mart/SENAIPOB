import math

base = int(input("Digite o primeiro numero: "))
expoente = int(input("Digite o segundo numero: "))

potencia = math.pow(base, expoente)

print(f'A potência de {base} por {expoente} é {potencia}')