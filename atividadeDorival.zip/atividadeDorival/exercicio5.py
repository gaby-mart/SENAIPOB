valor = "150"

numero = int(valor)
multiplicacao = numero * 2

print(f'{multiplicacao}')