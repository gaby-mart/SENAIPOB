nota1 = int(input("Digite a primeira nota:"))
nota2 = int(input("Digite a segunda nota:"))
nota3 = int(input("Digite a terceira nota:"))

p1 = int(input("Digite o peso da primeiro nota:"))
p2 = int(input("Digite o peso da segunda nota:"))
p3 = int(input("Digite o peso da terceira nota:"))

mediaPonderada= ((nota1*p1)+(nota2*p2)+(nota3*p3))/(p1+p2+p3)

print(f'A média ponderada é: {mediaPonderada}')