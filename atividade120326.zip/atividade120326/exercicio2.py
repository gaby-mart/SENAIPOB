qtdPeca = float(input("De quantas peças devo calcular o tempo de produção em horas: "))
tempoProducao = float(input(f"Em quantos minutos 1 peças é produzida:"))
tempoMin = float (qtdPeca * tempoProducao)

tempoHoras = float (tempoMin * 0.0166667)

print(f"O tempo de produção para {qtdPeca} peças é de {tempoHoras:.2f} horas.")