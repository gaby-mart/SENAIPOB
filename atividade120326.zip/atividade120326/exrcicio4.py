

velocidade = float(input("Qual a velocidade da Rede Mbps? "))
tempoSeg = float(input("Quantos tempo de download em segundos? "))

qtdDados = (velocidade * tempoSeg) / 8

print(f"A quantidade de Dados baixados foi: {qtdDados: 2.f}")