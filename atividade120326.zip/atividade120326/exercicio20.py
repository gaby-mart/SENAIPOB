import math

base = int(input("Digite uma base:"))
expoente = int(input("Digite o numero de expoente:"))

potencia = math.pow(base, expoente)

print(potencia)