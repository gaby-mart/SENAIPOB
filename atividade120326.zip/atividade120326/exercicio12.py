comprimento = float(input("Digite o comprimento de cada cabo: "))
qtdCabos = int(input("Digite a quantidade de cabos: "))

comprimentoTotal = comprimento * qtdCabos

print(f"O Comprimento total a ser instalado é: {comprimentoTotal}")