pecaPorMin = int(input("Informe as peças  produzidas por minuto: "))
temproProducao = int(input("Informe o tempo: "))

totalPecas = pecaPorMin * temproProducao

print(f"A quantidade de peças que serão produzidas em {temproProducao} é: {totalPecas}")