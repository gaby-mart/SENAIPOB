precoLicenca = float(input("Digite o valor da licença:"))
qtdFuncionarios = int(input("Digite a quantidade de funcionários:"))

totalLicenca = precoLicenca * qtdFuncionarios

print(f"O valor total das licenças é: {totalLicenca:.2f}")