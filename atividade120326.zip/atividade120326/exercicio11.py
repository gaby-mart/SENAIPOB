tempoTarefa = int(input("Qual é o tempo de execução por tarefa em segundos? "))
qtdTarefas = int(input("Quantas tarefas serão realizadas? "))

tempoSeg = tempoTarefa * qtdTarefas
tempoMin = tempoSeg / 60

print(f"Tempo em minutos para a realização de {qtdTarefas} é: {tempoMin}")