capacidadeHD = int(input("Digite a quantidade de capacidade do HD: "))
qtdHD = int(input("Digite a quantidade de HD: "))

capacidadeTotal = capacidadeHD * qtdHD

print(f"Capacidade total: {capacidadeTotal}")