largura = float(input("Largura da tela: "))
altura = float(input("Altura da tela: "))

area = largura * altura

print(f"A área da tela: {area}")