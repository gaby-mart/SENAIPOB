qtdCameras = int(input("Quantidade de cameras: "))
preco = int(input("Qual o preço de cada camera individualmente?"))
valorInstalacao = int(input("Qual o valor da instalação de cada camera individualmente?"))

precoTotal = qtdCameras * preco
precoInstalacao = qtdCameras * valorInstalacao

precoComIntalacao = precoTotal + precoInstalacao

print(f"O preço total do sistema é {precoComIntalacao}")