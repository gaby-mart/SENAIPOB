valorProduto = float(input("Digite o valor do produto: "))
valorFrete = float(input("Digite o valor do frete: "))
qtdProdutos = int(input("Quantos produtos deseja comprar: "))

valorParcial = float (valorProduto * qtdProdutos)
valorTotal = valorParcial + valorFrete

