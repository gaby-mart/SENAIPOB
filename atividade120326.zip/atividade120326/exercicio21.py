import math

a = float(input("Digite o valor do primeiro lado do triângulo: "))
b = float(input("Digite o valor do segundo lado: "))
c = float(input("Digite o valor do terceiro lado: "))

#Criação de um dicionário
tipos = {
    1: "Equilátero",
    2: "Isósceles",
    3: "Escaleno",
}

tipo = tipos[len(set([a, b, c]))] #Usa o set para remover valores repetidos e o len para contar a quantidade de valores

#Formula
p = (a+b+c)/2
area = math.sqrt(p*(p-a)*(p-b)*(p-c))

print(tipo)
print(f"A área do triângulo é: {area:.2f}")