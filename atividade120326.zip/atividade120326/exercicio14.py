tempoImprecao = int(input("Tempo de impressão desejado em minutos: "))
qtdPaginas = int(input("Quantas páginas são impressas por minuto??"))

tempoTotal = tempoImprecao * qtdPaginas

print(f"O total de páginas impressas em {tempoImprecao} é {tempoTotal}")

