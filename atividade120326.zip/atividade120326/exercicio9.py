qtdArquivos = int(input("Digite a quantidade de arquivos: "))
qtdMB = int(input("Digite a quantidade de MB por arquivos: "))

tamanhoMB = qtdArquivos * qtdMB
tamanhoGB = tamanhoMB / 1000

print(f"Tamamho dos arquivos GB: {tamanhoGB} gb")