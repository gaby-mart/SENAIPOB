valormensal = int(input("Valor mensal por hospedagem:"))
qtmeses = int(input("Quantidade de meses:"))

valorTotal = valormensal * qtmeses

print(f'Valor total: {valorTotal}')