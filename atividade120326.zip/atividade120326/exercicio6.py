qtdMemoria = float(input("Qual a quantidade de memoria RAM? "))
qtdComputadores = int(input("Qual a quantidade de computadores? "))

memoriaTotal = qtdMemoria * qtdComputadores

print(f"A quantidade total de memoria: {memoriaTotal: 2.f}")