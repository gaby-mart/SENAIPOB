qtdAcessos = int(input("Quantos Acessos: "))
qtdMinutos = int(input("Quantos minutos serão monitorados: "))

totalAcessos = qtdAcessos * qtdMinutos

print(f"Total de Acessos: {totalAcessos}")

