consumoWatts = int(input("Digite o consumo em wats de servidor:"))
qtdServidores = int(input("Quantos dervidores são:"))

consumoTotal = consumoWatts * qtdServidores

print(f"Total de energia em watts é: {consumoTotal}")