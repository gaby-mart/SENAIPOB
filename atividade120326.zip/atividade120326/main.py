qtdArquivos = int(input("Insira a quantidade de arquivos: "))

tamanho = []*qtdArquivos

for i in range(qtdArquivos):
    valor = int(input(f"Digite o valor da posição {i}: ")) * 0.001
    tamanho.append(valor)

print(f"A quatidade de espaço destinada aos {qtdArquivos} deve ser {tamanho}GB.")