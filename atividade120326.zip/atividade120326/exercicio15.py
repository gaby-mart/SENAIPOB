qtdHoras = int(input("Digite quantas horas de trabalho diário:"))
qtdDias = int(input("Digite quantidade de dias de projetos:"))

totalHoras = qtdHoras * qtdDias

print(f"Total de horas trabalhadas em projeto é: {totalHoras}")