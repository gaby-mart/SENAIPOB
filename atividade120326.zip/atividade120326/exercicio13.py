tamanhoMedio = int(input("Digite o tamanho médio de um login: "))
qtdLogin = int(input("Digite a quantidade de logins diários: "))

tamanhoTotal = tamanhoMedio * qtdLogin

print(f"O tamanho em MB de logins por dia é : {tamanhoTotal}")